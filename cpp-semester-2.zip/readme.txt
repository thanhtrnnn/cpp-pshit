Để bắt đầu:
- Mở file main.cpp và thực hiện compile code (khuyến nghị editor Visual Studio Code, compiler GDB 13.1/ g++ 13.1.0)
- Chạy chương trình và thực hiện theo hướng dẫn trong chương trình.